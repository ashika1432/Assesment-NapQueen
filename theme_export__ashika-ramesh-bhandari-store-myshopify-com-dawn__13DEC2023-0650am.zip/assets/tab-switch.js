document.querySelectorAll(".heading_tab_text").forEach((head) => {
  head.addEventListener("click", (event) => {
    let tabId = head.dataset.tab;
    
    document
      .querySelectorAll(".heading_tab_text")
      .forEach((h) => h.classList.remove("is--active"));
    document
      .querySelectorAll(".tab_content")
      .forEach((c) => c.classList.remove("is--active"));
    head.classList.add("is--active");
    document.getElementById(tabId).classList.add("is--active");
  });
});

//white space removal
 document.addEventListener("DOMContentLoaded", function() {
    var containers = document.querySelectorAll(".ingredients-container");

    containers.forEach(function(container) {
      var childDivs = container.querySelectorAll("div");
      var isEmpty = true;

      childDivs.forEach(function(childDiv) {
        if (childDiv.textContent.trim() !== "") {
          isEmpty = false;
        }
      });

      if (isEmpty) {
        container.style.display = "none";
      }
    });
  });